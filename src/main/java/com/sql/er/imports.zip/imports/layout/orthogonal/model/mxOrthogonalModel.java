/**
 * Copyright (c) 2008-2009, JGraph Ltd
 */
package com.sql.er.imports.layout.orthogonal.model;

import com.sql.er.imports.view.mxGraph;

/**
 * A custom graph model 
 */
public class mxOrthogonalModel
{
   public mxOrthogonalModel(mxGraph graph)
   {
      // 
   }
}
