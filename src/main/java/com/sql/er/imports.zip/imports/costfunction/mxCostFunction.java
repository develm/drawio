package com.sql.er.imports.costfunction;

import com.sql.er.imports.analysis.mxICostFunction;

public abstract class mxCostFunction implements mxICostFunction
{
}
