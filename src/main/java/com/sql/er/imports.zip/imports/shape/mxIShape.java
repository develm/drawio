package com.sql.er.imports.shape;

import com.sql.er.imports.canvas.mxGraphics2DCanvas;
import com.sql.er.imports.view.mxCellState;

public interface mxIShape
{
	/**
	 * 
	 */
	void paintShape(mxGraphics2DCanvas canvas, mxCellState state);

}
