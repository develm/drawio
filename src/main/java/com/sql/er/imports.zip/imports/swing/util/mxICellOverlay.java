package com.sql.er.imports.swing.util;

import com.sql.er.imports.util.mxRectangle;
import com.sql.er.imports.view.mxCellState;

public interface mxICellOverlay
{

	/**
	 * 
	 */
	mxRectangle getBounds(mxCellState state);

}
