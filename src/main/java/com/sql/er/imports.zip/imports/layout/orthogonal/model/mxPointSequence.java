/**
 * Copyright (c) 2008, Gaudenz Alder
 */
package com.sql.er.imports.layout.orthogonal.model;

/**
 *
 */
public class mxPointSequence
{

}
